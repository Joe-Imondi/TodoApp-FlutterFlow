import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAK0fPdSbi_cXtsUUR2IIt6RtAzuqfcmwY",
            authDomain: "todo-d86356.firebaseapp.com",
            projectId: "todo-d86356",
            storageBucket: "todo-d86356.firebasestorage.app",
            messagingSenderId: "220910967495",
            appId: "1:220910967495:web:59da57c410026c53813ce2"));
  } else {
    await Firebase.initializeApp();
  }
}
